package com.example.appcombustivelframe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class FcmActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fcm);

        TextView txtResposta = findViewById(R.id.txtOutraTela);
        TextView txtRespostaCaminhada = findViewById(R.id.txtCaminhada);
        TextView txtRespostaTrote = findViewById(R.id.txtTrote);
        TextView txtRespostaCorridaLeve = findViewById(R.id.txtCorridaLeve);
        TextView txtRespostaCorridaModerada = findViewById(R.id.txtCorridaModerada);
        TextView txtRespostaCorridaIntensa = findViewById(R.id.txtCorridaIntensa);


        Intent intent = getIntent();

        txtResposta.setText(intent.getStringExtra("fcm"));
        txtRespostaCaminhada.setText("Caminhada Rápida: " + intent.getStringExtra("cMin") + " a " + intent.getStringExtra("cMax"));
        txtRespostaTrote.setText("Trote: " + intent.getStringExtra("tMin") + " a " + intent.getStringExtra("tMax"));
        txtRespostaCorridaLeve.setText("Corrida Leve: " + intent.getStringExtra("clMin") + " a " + intent.getStringExtra("clMax"));
        txtRespostaCorridaModerada.setText("Corrida Moderada: " + intent.getStringExtra("cmMin") + " a " + intent.getStringExtra("cmMax"));
        txtRespostaCorridaIntensa.setText("Corrida Intensa: "  + "acima de " + intent.getStringExtra("ci"));



    }
}
