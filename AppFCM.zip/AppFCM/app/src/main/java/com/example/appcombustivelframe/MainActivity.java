package com.example.appcombustivelframe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.text.DecimalFormat;

import static android.icu.text.DisplayContext.LENGTH_SHORT;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void calcularFcm(View view){

        EditText txtIdade = findViewById(R.id.txtIdade);

        String strGasolina = txtIdade.getText().toString();

        double idade = Double.parseDouble(strGasolina);

        double resultado = 220 - idade;

        double caminhadaMin = resultado * 0.55;
        double caminhadaMax = resultado * 0.6;
        double troteMin = resultado * 0.65;
        double troteMax = resultado * 0.7;
        double corridaLeveMin = resultado * 0.75;
        double corridaLeveMax = resultado * 0.8;
        double corridaModeradaMin = resultado * 0.85;
        double corridaModeradaMax = resultado * 0.90;
        double corridaIntensa = resultado * 0.95;

        DecimalFormat df = new DecimalFormat("#.##");

        String cMin = String.valueOf(df.format(caminhadaMin)) + " bpm";
        String cMax = String.valueOf(df.format(caminhadaMax)) + " bpm";
        String tMin = String.valueOf(df.format(troteMin)) + " bpm";
        String tMax = String.valueOf(df.format(troteMax)) + " bpm";
        String clMin = String.valueOf(df.format(corridaLeveMin)) + " bpm";
        String clMax = String.valueOf(df.format(corridaLeveMax)) + " bpm";
        String cmMin = String.valueOf(df.format(corridaModeradaMin)) + " bpm";
        String cmMax = String.valueOf(df.format(corridaModeradaMax)) + " bpm";
        String ci = String.valueOf(df.format(corridaIntensa)) + " bpm";
        String fcm = String.valueOf(resultado) + " bpm";

        Intent intent = new Intent(this, FcmActivity.class);
        intent.putExtra("fcm", fcm);
        intent.putExtra("cMin", cMin);
        intent.putExtra("cMax", cMax);
        intent.putExtra("tMin", tMin);
        intent.putExtra("tMax", tMax);
        intent.putExtra("clMin", clMin);
        intent.putExtra("clMax", clMax);
        intent.putExtra("cmMin", cmMin);
        intent.putExtra("cmMax", cmMax);
        intent.putExtra("ci", ci);

        startActivity(intent);


    }

}
